#ifndef __CR_ASM_PARASITE_SYSCALL_H__
#define __CR_ASM_PARASITE_SYSCALL_H__

#include "asm/types.h"

struct parasite_ctl;

#endif
