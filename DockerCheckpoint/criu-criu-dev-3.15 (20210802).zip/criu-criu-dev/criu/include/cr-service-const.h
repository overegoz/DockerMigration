#ifndef __CR_SERVICE_CONST_H__
#define __CR_SERVICE_CONST_H__

#define CR_DEFAULT_SERVICE_ADDRESS "./criu_service.socket"

#endif /* __CR_SERVICE_CONST_H__ */
