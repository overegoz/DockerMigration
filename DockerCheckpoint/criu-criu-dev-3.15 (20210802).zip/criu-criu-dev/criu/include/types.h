#ifndef __CR_INC_TYPES_H__
#define __CR_INC_TYPES_H__
#include <compel/asm/infect-types.h>
#include "asm/types.h"
#endif
