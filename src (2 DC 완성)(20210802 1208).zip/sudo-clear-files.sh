#!/bin/bash

rm -rf /home/daniel/migration/DC-CheckPoints/*
rm -rf /home/daniel/migration/DiffCopyFiles/*
rm -rf /home/daniel/migration/FC-CheckPoints/*
rm -rf /home/daniel/migration/FullCopyImages/*
rm -rf /home/daniel/migration/LogReplayRecords/*
rm diff-*.txt