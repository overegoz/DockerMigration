#!/bin/bash

export PYTHONUNBUFFERED=1
python3 ap-3.py AP-2 $1